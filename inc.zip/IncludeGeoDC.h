#ifndef	_IncludeGeoDC_h
#define	_IncludeGeoDC_h

#include "../LibSrc/GeoDC/GDCGeo.h"
#include "../LibSrc/GeoDC/GRgn.h"

#endif // _IncludeGeoDC_h

////////////////////////////////////////////////////////////////////////////////
//
// �� ���α׷� �ҽ��� ���� ��� �Ǹ��� (��)�������ַ�ǿ� �ֽ��ϴ�.
// Copyright (C) C&G Solution, Inc. All rights reserved.
//
// �� ���α׷� �ҽ��� '�����ȣ ���� ǥ�� ������Ʈ ����� ���� SDK'
// (���� 'SDK')�� ���Ե��� ���� ��� (��)�������ַ���� ���� ���ξ��� ���Ƿ�
// ����/����/����/������ �� �����ϴ�.
//
// �� ���α׷� �ҽ��� SDK�� ���Ե� ��� SDK�� �Ϻημ� ����/������ �����ϳ�,
// ���� ���Ϸ� ������ �� ������ SDK ���·� �����ؾ� �մϴ�.
//
// SDK�� ���Ե� ���α׷� �ҽ��� SDK�� ����Ͽ� �����ϴ� �������α׷��� ��������
// ���� �����ϴ� ���̸� �뵵 �̿��� �������� ����� �� �����ϴ�.
//
// ����������Ż�ɺθ� ���Ͽ� �����ϴ� SDK�� �ѱ����� ����� �������� ü�踦
// �����ϱ� ���� ������ �����ϴ� ��� ������ ���������� ���߿� ���Ͽ� ���� ��
// ����� �����մϴ�.
//
// ���/�������/������ SDK�� ����Ͽ� ��ǰ�� �����ϰų� ���� �Ǵ� �н��ϰ���
// �ϴ� ��� ������ (��)�������ַ�ǰ� �����ؾ� �մϴ�.
//
// �ѱ����� ����� ���� ü�� ������ ���� ������ ������ ��� ������ �����̶�
// ����� ��ǰ ���߿� SDK�� ����� ��� ������ (��)�������ַ�ǰ� �����ؾ� �ϸ�
// (��)�������ַ���� SDK �� �������� ���Ḧ û���� �� �ֽ��ϴ�.
// 
//
// �ۼ��� : (��)�������ַ�� ��â��, H.P: 010-2352-1487, E-mail: cgyim@korea.com
// �ۼ��� : 2010/08/15
//
////////////////////////////////////////////////////////////////////////////////

#pragma once
#include "IcopsUnknown.h"


namespace ICOPS
{

////////////////////////////////////////////////////////////////////////////////
// Primitive data types

typedef CArray<double, double> CDoubleArray;


////////////////////////////////////////////////////////////////////////////////
//

#define EARTH_RADIUS		6378140	// meter
#define EARTH_ESSENTRICITY	0.0167
//������ ������������ �� 6378 km,
//�ع������� �� 6357 km ��
//������������ �ع������� ���̴�
//�� 21 km �Դϴ�.
//�̿� ���� ������ ���򵵴�
//
//���� = 1 - ( �ع����� / ���������� )
//      = 0.0033
//     �� 1 / 300  ( 1 / 298 )
//�� 1 / 300 �Դϴ�.
//


////////////////////////////////////////////////////////////////////////////////
// Component library and component

// Required information to create component object
typedef struct SComponentCreationInfo
{
	CString		lib;
	CString		ext;
	CString		cls;
} SComponentCreationInfo;
typedef CTypedPtrArray<CPtrArray, SComponentCreationInfo *> CPtrArraySComponentCreationInfo;
typedef CTypedPtrList<CPtrList, SComponentCreationInfo *> CPtrListSComponentCreationInfo;


struct SComLib;

typedef struct SComponent
{
	CString	cls;	// Component class name
	CString	impl;	// Component major interface
	CString	desc;	// Component description
	SComLib	*lib;	// Link to the component library variable

	SComponent &operator=(const SComponent &r)
	{
		cls = r.cls;
		impl = r.impl;
		desc = r.desc;
		lib = r.lib;
		return *this;
	};
} SComponent;
typedef CTypedPtrArray<CPtrArray, SComponent *> CPtrArraySComponent;
typedef CTypedPtrList<CPtrList, SComponent *> CPtrListSComponent;


typedef struct SComLib
{
	CString	lib;	// Component library file name
	CString	ext;	// Library file extension name
	CString	name;	// Component library name
	CString	desc;	// Component library description
	CPtrArraySComponent	coms;	// Component information list
} SComLib;
typedef CTypedPtrArray<CPtrArray, SComLib *> CPtrArraySComLib;
typedef CTypedPtrList<CPtrList, SComLib *> CPtrListSComLib;

//#define ICOPS_COM_LIB(lib)		SComLib		ComLib_##lib = { CString(_T(""#lib"")) }
//#define ICOPS_COM(lib, name)	SComponent	Com_##name = { &ComLib_##lib, CString(_T("C"#name"")) }


typedef struct SCustomComponent
{
	CString		lib;	// Library name of custom component
	CString		ext;	// Library file extension name
	CString		cls;	// Class name of custom component
	CString		impl;	// Target interface name to customize

	SCustomComponent &operator=(const SCustomComponent &r)
	{
		lib = r.lib;
		ext = r.ext;
		cls = r.cls;
		impl = r.impl;
		return *this;
	};
} SCustomComponent;
typedef CTypedPtrArray<CPtrArray, SCustomComponent *> CPtrArraySCustomComponent;
typedef CTypedPtrList<CPtrList, SCustomComponent *> CPtrListSCustomComponent;


typedef struct STopicAgentComponent
{
	CString		lib;	// Library name of topic agent component
	CString		ext;	// Library file extension name
	CString		cls;	// Class name of topic agent component
	CString		impl;	// Target interface name to customize
	CString		name;	// Topic agent name

	STopicAgentComponent &operator=(const STopicAgentComponent &r)
	{
		lib = r.lib;
		ext = r.ext;
		cls = r.cls;
		impl = r.impl;
		name = r.name;
		return *this;
	};
} STopicAgentComponent;
typedef CTypedPtrArray<CPtrArray, STopicAgentComponent *> CPtrArraySTopicAgentComponent;
typedef CTypedPtrList<CPtrList, STopicAgentComponent *> CPtrListSTopicAgentComponent;


typedef struct SProperty
{
	CString		name;	// Property name
	CString		value;	// Property value

	SProperty &operator=(const SProperty &r)
	{
		name = r.name;
		value = r.value;
		return *this;
	};
} SProperty;
typedef CTypedPtrArray<CPtrArray, SProperty *> CPtrArraySProperty;
typedef CTypedPtrList<CPtrList, SProperty *> CPtrListSProperty;


typedef struct SStockObject
{
	CString			libName;	// Library name of stock object
	CString			clsName;	// Class name of stock object
	CString			ifName;		// Implementing interface name
	IcopsUnknown	*stock;		// Stock object

	SStockObject()
	{
		stock = NULL;
	}
	~SStockObject()
	{
		if (stock!=NULL)
		{
			stock->Release();
			stock = NULL;
		}
	}
} SStockObject;
typedef CTypedPtrArray<CPtrArray, SStockObject *> CPtrArraySStockObject;
typedef CTypedPtrList<CPtrList, SStockObject *> CPtrListSStockObject;


////////////////////////////////////////////////////////////////////////////////
// Data processing state

typedef enum EDataProcessingState {
	NoData,		// �ڷᰡ ���� ���¿��� �����
	Requested,	// �б� �����
	Loading,	// �ڷ� �д� ��
	Canceled,	// �ڷ� �б� ��ҵ�
	Deleting,	// �ڷ� �ִ� ���¿��� ���� �����
	Ready,		// �ڷ� �ִ� ���¿��� �����
	Failed		// �ڷᰡ ��� ���� �� ���� ����
} EDataProcessingState;


////////////////////////////////////////////////////////////////////////////////
// Layer

interface ILayer;

typedef struct SLayerAttribute
{
	UINT	order;
	GUID	layerID;
	GUID	oid;
	CString	name;
	CString	sub_hpath;
	BOOL	show;
	CString	url;
	UINT	transparency;	// 0 (opaque) ~ 100 (transparent)

	SLayerAttribute()
	{
		order = 0;
		layerID = GUID_NULL;
		oid = GUID_NULL;
		name.Empty();
		sub_hpath.Empty();
		show = TRUE;
		url.Empty();
		transparency = 0;
	};
	SLayerAttribute &operator=(const SLayerAttribute &r)
	{
		order = r.order;
		layerID = r.layerID;
		oid = r.oid;
		name = r.name;
		sub_hpath = r.sub_hpath;
		show = r.show;
		url = r.url;
		transparency = r.transparency;
		return *this;
	};
} SLayerAttribute;
typedef CTypedPtrArray<CPtrArray, SLayerAttribute *> CPtrArraySLayerAttribute;
typedef CTypedPtrList<CPtrList, SLayerAttribute *> CPtrListSLayerAttribute;


////////////////////////////////////////////////////////////////////////////////
// Coordinates

// Geographic space
typedef struct SGeoCoord2
{
	double	lon;
	double	lat;

	SGeoCoord2() { lon = 0.0; lat = 0.0; };
	SGeoCoord2(double _lon, double _lat) { lon = _lon; lat = _lat; };
	SGeoCoord2 &operator=(const SGeoCoord2 &r)
	{
		lon = r.lon;
		lat = r.lat;
		return *this;
	};
	BOOL operator==(const SGeoCoord2 &r) { return (lon==r.lon && lat==r.lat); };
	BOOL operator!=(const SGeoCoord2 &r) { return (lon!=r.lon || lat!=r.lat); };
	SGeoCoord2 operator-() { return SGeoCoord2(-lon, -lat); };
	SGeoCoord2 operator-(SGeoCoord2 src) { return SGeoCoord2(lon - src.lon, lat - src.lat); };
	SGeoCoord2 operator+(SGeoCoord2 src) { return SGeoCoord2(lon + src.lon, lat + src.lat); };
} SGeoCoord2;

typedef struct SGeoCoord3
{
	double	lon;
	double	lat;
	double	height;

	SGeoCoord3 &operator=(const SGeoCoord3 &r)
	{
		lon = r.lon;
		lat = r.lat;
		height = r.height;
		return *this;
	};
	SGeoCoord3(double _lon, double _lat, double _height) { lon = _lon; lat = _lat; height = _height; };
	BOOL operator==(const SGeoCoord3 &r) { return (lon==r.lon && lat==r.lat && height==r.height); };
	BOOL operator!=(const SGeoCoord3 &r) { return (lon!=r.lon || lat!=r.lat || height!=r.height); };
	SGeoCoord3 operator-() { return SGeoCoord3(-lon, -lat, -height); };
	SGeoCoord3 operator-(SGeoCoord3 src) { return SGeoCoord3(lon - src.lon, lat - src.lat, height - src.height); };
	SGeoCoord3 operator+(SGeoCoord3 src) { return SGeoCoord3(lon + src.lon, lat + src.lat, height + src.height); };
} SGeoCoord3;


// Euclidian space
typedef struct SOrthoCoord2
{
	double	x;
	double	y;

	SOrthoCoord2() { x = 0.0; y = 0.0; };
	SOrthoCoord2(double _x, double _y) { y = _x; y = _y; };
	SOrthoCoord2 &operator=(const SOrthoCoord2 &r)
	{
		x = r.x;
		y = r.y;
		return *this;
	};
	BOOL operator==(const SOrthoCoord2 &r) { return (x==r.x && y==r.y); };
	BOOL operator!=(const SOrthoCoord2 &r) { return (x!=r.x || y!=r.y); };
} SOrthoCoord2;

typedef struct SOrthoCoord3
{
	double	x;
	double	y;
	double	z;

	SOrthoCoord3 &operator=(const SOrthoCoord3 &r)
	{
		x = r.x;
		y = r.y;
		z = r.z;
		return *this;
	};
	BOOL operator==(const SOrthoCoord3 &r) { return (x==r.x && y==r.y && z==r.z); };
	BOOL operator!=(const SOrthoCoord3 &r) { return (x!=r.x || y!=r.y || z!=r.z); };
} SOrthoCoord3;


//// Spherical coordinate space
//typedef struct SSphericalCoordinate2
//{
//	double	radius;	// Distance from origin
//	double	theta;	// Angle from X axis along X-Y plane
//
//	SSphericalCoordinate2 &operator=(const SSphericalCoordinate2 &r)
//	{
//		radius = r.radius;
//		theta = r.theta;
//		return *this;
//	};
//} SSphericalCoordinate2;
//
//typedef struct SSphericalCoordinate3
//{
//	double	radius;	// Distance from origin
//	double	theta;	// Angle from X axis along X-Y plane
//	double	pi;		// Angle from Z axis.
//
//	SSphericalCoordinate3 &operator=(const SSphericalCoordinate3 &r)
//	{
//		radius = r.radius;
//		theta = r.theta;
//		pi = r.pi;
//		return *this;
//	};
//} SSphericalCoordinate3;

// End of Coordinates
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Camera attributes

typedef enum _ECameraType {
	CartesianCamera = 1,
	SphericalCamera = 2
} ECameraType;


typedef struct SCartesianCamera {
	ECameraType		type;		// Camera type
#if defined(_ICOPS_3D_DirectX)
	D3DXVECTOR3		pos;		// Camera position
	D3DXVECTOR3		look;		// Looking at position
	D3DXVECTOR3		up;			// Head up vector
	D3DVIEWPORT9	viewport;	// Viewport
#elif defined(_ICOPS_3D_OpenGL)
#endif
	float			fov;		// Field of view in the y direction (focus angle), in radians

	SCartesianCamera()
	{
#if defined(_ICOPS_3D_DirectX)
		type = CartesianCamera;
		pos = D3DXVECTOR3(0.0, 4.0 * EARTH_RADIUS, 0.0);
		look = D3DXVECTOR3(0.0, 0.0, 0.0);
		up = D3DXVECTOR3(0.0, 0.0, 1.0);

		viewport.X = 0;	viewport.Y = 0;
		viewport.Width = 640;
		viewport.Height = 480;
		viewport.MinZ = 0.0f;
		viewport.MaxZ = 1.0f;

		fov = D3DXToRadian(45.0f);
#elif defined(_ICOPS_3D_OpenGL)
#endif
	};
	SCartesianCamera &operator=(const SCartesianCamera &r)
	{
#if defined(_ICOPS_3D_DirectX)
		type = r.type;
		pos = r.pos;
		look = r.look;
		up = r.up;
		//right = r.right;
		viewport = r.viewport;
		fov = r.fov;
#elif defined(_ICOPS_3D_OpenGL)
#endif
		return *this;
	};
} SCartesianCamera;


typedef struct SSphericalCamera
{
	// x axis : Direction from center of the earth to (90, 0);
	// y axis : Direction from center of the earth to (0, 0)
	// z axis : Earth axis. North is positive, South is negative.

#if defined(_ICOPS_3D_DirectX)
	D3DXVECTOR3		sphericalPos;	// Camera position in spherical coordinate (x, y, z) => (lon, lat, height) in radian
	D3DXVECTOR3		sphericalLook;	// Looking at position in spherical coordinate (x, y, z) => (lon, lat, height) in radian
	D3DXVECTOR3		sphericalUp;	// Head up vector in spherical coordinate (x, y, z) => (longitudinal distance, latitudinal distance, height) in radian
	SGeoCoord2		mapOrigin;
	D3DXVECTOR3		eradius;	// Radius of ellipsoid (x, y, z) => (rx, ry, rz)
#elif defined(_ICOPS_3D_OpenGL)
#endif

	SSphericalCamera()
	{
#if defined(_ICOPS_3D_DirectX)
		sphericalPos = D3DXVECTOR3(0.0, 0.0, 3 * EARTH_RADIUS);
		sphericalLook = D3DXVECTOR3(0.0, 0.0, 0.0);
		sphericalUp = D3DXVECTOR3(0.0, 1.0, 0.0);
		mapOrigin = SGeoCoord2(0.0, 0.0);
		eradius = D3DXVECTOR3(EARTH_RADIUS, EARTH_RADIUS, EARTH_RADIUS);
#elif defined(_ICOPS_3D_OpenGL)
#endif
	};
	SSphericalCamera &operator=(const SSphericalCamera &r)
	{
#if defined(_ICOPS_3D_DirectX)
		sphericalPos = r.sphericalPos;
		sphericalLook = r.sphericalLook;
		sphericalUp = r.sphericalUp;
		mapOrigin = r.mapOrigin;
		eradius = r.eradius;
#elif defined(_ICOPS_3D_OpenGL)
#endif
		return *this;
	};
} SSphericalCamera;


// End of Camera attributes
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Render state

typedef struct SRenderStates {
#if defined(_ICOPS_3D_DirectX)
	D3DZBUFFERTYPE	m_eDepthBufferType;	// Depth buffer type : disable/z-buffering/w-buffering : D3DRS_ZENABLE
	D3DFILLMODE		m_eFillMode;		// Fill mode : point/wireframe/solid : D3DRS_FILLMODE
	BOOL			m_bLightOn;			// Light mode : on/off : D3DRS_LIGHTING
	D3DSHADEMODE	m_eShadeMode;		// Shade mode : flat/gouraud/phong : D3DRS_SHADEMODE
	D3DCULL			m_eCull;			// Cull mode : none/clockwise/counter clockwise : D3DRS_CULLMODE
#elif defined(_ICOPS_3D_OpenGL)
#endif

	SRenderStates()
	{
#if defined(_ICOPS_3D_DirectX)
		m_eDepthBufferType = D3DZB_TRUE;
		m_eFillMode = D3DFILL_SOLID;	// D3DFILL_POINT, D3DFILL_WIREFRAME, D3DFILL_SOLID
		m_bLightOn = FALSE;
		m_eShadeMode = D3DSHADE_FLAT;
		m_eCull = D3DCULL_CW;
#elif defined(_ICOPS_3D_OpenGL)
#endif
	}; 
	SRenderStates &operator=(const SRenderStates &r)
	{
#if defined(_ICOPS_3D_DirectX)
		m_eDepthBufferType = r.m_eDepthBufferType;
		m_eFillMode = r.m_eFillMode;
		m_bLightOn = r.m_bLightOn;
		m_eShadeMode = r.m_eShadeMode;
#elif defined(_ICOPS_3D_OpenGL)
#endif
		return *this;
	};
} SRenderStates;

// End of Render state
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Minimum Bounding Rectangle

enum EMBRtype { MBR_int, MBR_float, MBR_double };

typedef struct SMBR_int {
	int	left;
	int	top;
	int	right;
	int	bottom;

	SMBR_int() { left = 0; top = 0; right = 0; bottom = 0; };
	SMBR_int(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; };
	const SMBR_int &operator = (const SMBR_int &r) { left = r.left; top = r.top; right = r.right; bottom = r.bottom; return *this; };
	inline BOOL	IsCross(const SMBR_int &r) const { return !(right<r.left || left>r.right || top<r.bottom || bottom>r.top); };
	inline BOOL IsContainedBy(const SMBR_int &r) const { return (r.left<=left && r.right>=right && r.top>=top && r.bottom<=bottom); };
} SMBR_int;

typedef struct SMBR_float {
	float	left;
	float	top;
	float	right;
	float	bottom;

	SMBR_float() { left = 0.0f; top = 0.0f; right = 0.0f; bottom = 0.0f; };
	SMBR_float(float l, float t, float r, float b) { left = l; top = t; right = r; bottom = b; };
	const SMBR_float &operator = (const SMBR_float &r) { left = r.left; top = r.top; right = r.right; bottom = r.bottom; return *this; };
	inline BOOL	IsCross(const SMBR_float &r) const { return !(right<r.left || left>r.right || top<r.bottom || bottom>r.top); };
	inline BOOL IsContainedBy(const SMBR_float &r) const { return (r.left<=left && r.right>=right && r.top>=top && r.bottom<=bottom); };
} SMBR_float;

typedef struct SMBR_double {
	double	left;
	double	top;
	double	right;
	double	bottom;

	SMBR_double() { left = 0.0f; top = 0.0f; right = 0.0f; bottom = 0.0f; };
	SMBR_double(double l, double t, double r, double b) { left = l; top = t; right = r; bottom = b; };
	const SMBR_double &operator = (const SMBR_double &r) { left = r.left; top = r.top; right = r.right; bottom = r.bottom; return *this; };
	inline BOOL	IsCross(const SMBR_double &r) const { return !(right<r.left || left>r.right || top<r.bottom || bottom>r.top); };
	inline BOOL IsContainedBy(const SMBR_double &r) const { return (r.left<=left && r.right>=right && r.top>=top && r.bottom<=bottom); };
} SMBR_double;

// End of Minimum Bounding Rectangle
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Elevation data block

typedef struct SElevDataHeader {
	float	left;
	float	top;
	float	right;
	float	bottom;
	float	pixgap;
	float	_pack1;	// reserved for packing space
	INT_PTR	ncol;
	INT_PTR	nrow;
	short	*data;

	SElevDataHeader()
	{
		left = 0.0f;
		top = 0.0f;
		right = 0.0f;
		bottom = 0.0f;
		pixgap = 0.0f;
		ncol = 0;
		nrow = 0;
		data = NULL;
	};
	~SElevDataHeader() { if (data!=NULL) delete[] data; };
	SElevDataHeader &operator=(const SElevDataHeader &r)
	{
		left = r.left;
		top = r.top;
		right = r.right;
		bottom = r.bottom;
		pixgap = r.pixgap;
		ncol = r.ncol;
		nrow = r.nrow;
		if (r.data==NULL) data = NULL;
		else
		{
			data = new short[ncol * nrow];
			::CopyMemory(data, r.data, sizeof(short) * ncol * nrow);
		}
		return *this;
	};
} SElevDataHeader;

// End of Elevation data block
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Graphic editing tool

// ���� ����
typedef enum _EHitStatus
{
	HitStatus_None = 0,			// �������� ����

	HitStatus_Point = 1,		// ��
	HitStatus_Line = 2,			// ��
	HitStatus_Face = 3,			// ��

	HitStatus_Left = 4,			// ��
	HitStatus_Top = 5,			// ��
	HitStatus_Right = 6,		// ��
	HitStatus_Bottom = 7,		// ��

	HitStatus_LeftTop = 8,		// �»�
	HitStatus_LeftBottom = 9,	// ����
	HitStatus_RightTop = 10,	// ���
	HitStatus_RightBottom = 11,	// ����

	HitStatus_Rotate = 12,		// ȸ��
	HitStatus_Text = 13,		// ���ڿ�
	HitStatus_Link = 14,		// ������
	HitStatus_Modifier = 15,	// ������
} EHitStatus;


// ���� Ȯ�� ���
typedef struct _SHitResult
{
	EHitStatus	eStatus;	// ���� ����
	void		*pObj;		// ���� ��� ��ü
	INT_PTR		ctrlInx;	// ���˵� ������ �ε���
} SHitResult;


// End of Graphic editing tool
////////////////////////////////////////////////////////////////////////////////

};	// end of namespace ICOPS

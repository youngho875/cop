#include "pch.h"
#include "OverlayFileRecordHeader.h"
#include "OverlayFileRecordCommon.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
	OverlayFileRecordHeader::OverlayFileRecordHeader()
	{
		eRecordType = OVERLAY_RECORD_TYPE_COMMON;
		nDataSize = sizeof(OverlayFileRecordCommon);
	}

	OverlayFileRecordHeader::~OverlayFileRecordHeader()
	{
	}
//}
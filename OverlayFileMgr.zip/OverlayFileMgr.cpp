#include "pch.h"
#include "OverlayFileMgr.h"
#include "../C4IMap.h"
#include "../MainFrm.h"
#include "../C4IMapDoc.h"
#include "../OverlayMain.h"
#include "../../inc/includeOverlay.h"
//#include "../../LIBSrc/Overlay/ObjectText.h"
//#include "../../LIBSrc/Overlay/ObjectImage.h"
//#include "../../LIBSrc/Overlay/ObjectPie.h"
//#include "../../LIBSrc/Overlay/ObjectArc.h"
//#include "../../LIBSrc/Overlay/ObjectEllipse.h"
//#include "../../LIBSrc/Overlay/ObjectPie.h"
//#include "../../LIBSrc/Overlay/ObjectArc.h"
//#include "../../LIBSrc/Overlay/ObjectTriangle.h"
//#include "../../LIBSrc/Overlay/ObjectRect.h"
//#include "../../LIBSrc/Overlay/ObjectRoundRect.h"
//#include "../../LIBSrc/Overlay/ObjectLine.h"
//#include "../../LIBSrc/Overlay/ObjectDiamond.h"
//#include "../../LIBSrc/Overlay/ObjectPolyLine.h"
//#include "../../LIBSrc/Overlay/ObjectPolygon.h"
//#include "../../LIBSrc/Overlay/ObjectPentagon.h"
//#include "../../LIBSrc/Overlay/ObjectSixAngle.h"
//#include "../../LIBSrc/Overlay/ObjectEightAngle.h"
//#include "../../LIBSrc/Overlay/ObjectImage.h"
//#include "../../LIBSrc/Overlay/ObjectText.h"
//#include "../../LIBSrc/Overlay/ObjectCurve.h"
//#include "../../LIBSrc/Overlay/ObjectLinkedLine.h"
//#include "../../LIBSrc/Overlay/ObjectLinkedMultiLine.h"
//#include "../../LIBSrc/Overlay/ObjectLinkedCurve.h"
//#include "../../LIBSrc/Overlay/ObjectLinkedMultiCurve.h"
#include <io.h>
#include "../FilePath.h"
#include "../../inc/GlobalInfo.h"


#include <RpcDce.h>
#include <string>
//#include <afxwin.h>
//#include <windows.h>

using namespace std;
using namespace OVERLAY;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
COverlayFileMgr::COverlayFileMgr(COverlayMain* pOverlayMain)
{
	m_pOverlayMain = pOverlayMain;
}

COverlayFileMgr::~COverlayFileMgr()
{

}

BOOL COverlayFileMgr::CheckValidation(OverlayFileHeader stFileHeader)
{
	ULONGLONG nFileLength = CFile::GetLength();
	if(stFileHeader.nFileSize !=nFileLength )
		return FALSE;

	if(stFileHeader.nFileCode != OVERLAY_FILE_MAGIC_NUM)
		return FALSE;

	return TRUE;
}

void COverlayFileMgr::RecordCommon(OVERLAY::OBJECT* pObject, CLayerStructure* pLayer)
{	
	//CString p;
	CString xmlNode;

	//OverlayFileRecordHeader	RecordHeader;
	//OverlayFileRecordCommon RecordData;
	OverlayFileRecordText RecordData;

	//Recrod Header
	//RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_COMMON;
	//RecordHeader.nDataSize = sizeof(RecordData);
	//Write((BYTE*)&RecordHeader,sizeof(RecordHeader));

	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);

	if(!xmlDataSave(&RecordData, pLayer))
		AfxMessageBox("������ �������� ���߽��ϴ�");

	//Write((BYTE*)&RecordData,sizeof(RecordData));
}


// ��ü�� ���Ͽ� xml ���Ϸ� ����
BOOL COverlayFileMgr::xmlDataSave(OverlayFileRecordText *RecordData, CLayerStructure* pLayer)
{
	CString xmlNode = _T("");
	CString strXml;

	if(RecordData != NULL)
	{
		//if(RecordData->m_nObjectID == 1)//�����϶� 
		//{
		//	xmlNode = m_xml.SetOVS(RecordData, pLayer); 
		//}
		if(RecordData->m_nObjectID == 1)//�����϶� 
		{
			xmlNode = m_xml.SetOVI(RecordData, pLayer);
		}
		xmlNode += "\t"+ m_xml.SetOVS(RecordData, pLayer); 
		xmlNode += "\t\t"+ m_xml.SetGEO(RecordData);				// ��ȣ ���� ����

		if(RecordData->m_eType != 12)
		{
			xmlNode += "\t\t"+ m_xml.LineProperty(RecordData);		// ��ȣ �� �Ӽ�
				xmlNode += "\t\t"+ m_xml.StartLineCap(RecordData);	
				xmlNode += "\t\t\t"+ m_xml.EndLineCap(RecordData);
				xmlNode += "\t\t\t"+ m_xml.LineDash(RecordData);
				xmlNode += "\t\t\t"+ m_xml.HatchBrush(RecordData);	// ��ȣ ä�� �Ӽ�(���ο� ���� ó��)
				xmlNode += "\t\t\t"+ m_xml.PathGradient(RecordData);	//
				xmlNode += "\t\t\t"+ m_xml.LinerGradient(RecordData);	//
			xmlNode += "\t\t</lp>\n";
		}
		if(RecordData->m_eType == 4 || RecordData->m_eType == 5 ||
			RecordData->m_eType == 7 || RecordData->m_eType == 9 ||
			RecordData->m_eType == 17 || RecordData->m_eType == 8)
		{
			xmlNode += "\t\t"+ m_xml.FillProperty(RecordData);		// ��ȣ ä�� �Ӽ�(�鿡 ���� ó��)	
				xmlNode += "\t\t\t"+ m_xml.HatchBrush(RecordData);	
				xmlNode += "\t\t\t"+ m_xml.PathGradient(RecordData);
				xmlNode += "\t\t\t"+ m_xml.LinerGradient(RecordData);
			xmlNode += "\t\t</fp>\n";
		}
		xmlNode += "\t\t"+ m_xml.TextProperty(RecordData);		// ��ȣ ���� �Ӽ�

		switch(RecordData->m_eType)
		{
		case 2:
			xmlNode += "\t\t"+ m_xml.SetSPT(RecordData);	// ����ȣ
			break;
		case 4:
		case 5:
			xmlNode += "\t\t"+ m_xml.SetSRT(RecordData);	// �簢�� ��ȣ
			break;
		case 7:
			xmlNode += "\t\t"+ m_xml.SetSEL(RecordData);	// Ÿ�� ��ȣ
			break;
		case 9:
		case 17:
			xmlNode += "\t\t"+ m_xml.SetSAR(RecordData);	// ȣ ��ȣ
			break;
		case 8:
			xmlNode += "\t\t"+ m_xml.SetSPL(RecordData);	// �ٰ��� ��ȣ
			break;
		case 23:
			xmlNode += "\t\t"+ m_xml.SetSTS(RecordData);	// ���� ��ȣ
			break;
		}
		xmlNode += "\t\t"+ m_xml.SetSTS(RecordData);
		xmlNode += "\t</ovs>\n";
		if(!pLayer->get_object_with_index(RecordData->m_nObjectID))//�����϶�
			xmlNode += "</ovi>";

		Write(xmlNode, xmlNode.GetLength());

		return TRUE;
	}
	return FALSE;
}


void COverlayFileMgr::RecordImage(OVERLAY::OBJECT* p)
{	
	OverlayFileRecordHeader	RecordHeader;
	OverlayFileRecordImage	RecordData;
	OVERLAY::ObjectImage* pObject = (OVERLAY::ObjectImage*)p;

	//Record Header
	RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_IMAGE;
	RecordHeader.nDataSize = sizeof(RecordData);

	Write((BYTE*)&RecordHeader,sizeof(RecordHeader));
	TRACE("File Position : %d\n",GetPosition());
	
	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);

	memset(RecordData.m_szImageFileName,0,sizeof(RecordData.m_szImageFileName));
	memcpy(RecordData.m_szImageFileName,pObject->m_strImageFileName ,strlen(pObject->m_strImageFileName));

	RecordData.m_nImageSize = 0;
	FILE* hImageFile=NULL; 
	hImageFile = fopen(RecordData.m_szImageFileName,_T("rb"));

	int nReadSize=0;
	DWORD nCurrentFilePosition=0;
	DWORD nTempCurrentFilePosition=0;
	BYTE ImageBuffer[1024];
	memset(ImageBuffer, 0, sizeof(ImageBuffer));

	if(hImageFile<=0)
		Write((BYTE*)&RecordData,sizeof(RecordData));
	else
	{
		RecordData.m_nImageSize = 0;
		nCurrentFilePosition = (DWORD)CFile::GetPosition();
		Write((BYTE*)&RecordData,sizeof(RecordData));

		while(1)
		{
			nReadSize = fread((BYTE*)ImageBuffer,sizeof(BYTE),1024,hImageFile);
			if(nReadSize<=0)
			{
				CFile::Seek(nCurrentFilePosition,CFile::begin);
				Write((BYTE*)&RecordData,sizeof(RecordData));
				break;
			}
			RecordData.m_nImageSize += nReadSize;
			Write((BYTE*)ImageBuffer,nReadSize );
			nTempCurrentFilePosition = (DWORD)CFile::GetPosition();
		}
	}

	CFile::Seek(nTempCurrentFilePosition,CFile::begin);
	TRACE("File Position : %d\n",GetPosition());
	if(hImageFile>0)
		fclose(hImageFile);	
}

void COverlayFileMgr::RecordText(OVERLAY::OBJECT* p, CLayerStructure* pLayer)
{
	//OverlayFileRecordHeader	RecordHeader;
	OverlayFileRecordText	RecordData;
	OVERLAY::ObjectText* pObject = (OVERLAY::ObjectText*)p;

	//Record Header
	//RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_TEXT;
	//RecordHeader.nDataSize = sizeof(RecordData);

	//Write((BYTE*)&RecordHeader,sizeof(RecordHeader));
	
	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);

	RecordData.m_dFontSize = pObject->GetFontSize();
	RecordData.m_eFamilyName = pObject->GetFamilyName();
	RecordData.m_eUnit = pObject->GetUnit();
	RecordData.m_FontColor = pObject->GetFontColor();
	RecordData.m_eFontStyle = pObject->GetFontStyle();
	memcpy(RecordData.m_Text, pObject->GetText(), sizeof(RecordData.m_Text));

	if(!xmlDataSave(&RecordData, pLayer))
		AfxMessageBox("������ �������� ���߽��ϴ�");

	//Write((BYTE*)&RecordData,sizeof(RecordData));
}

// ��ä��
void COverlayFileMgr::RecordPie(OVERLAY::OBJECT* p, CLayerStructure* pLayer)
{
	//OverlayFileRecordHeader	RecordHeader;
	OverlayFileRecordText RecordData;
	OVERLAY::ObjectPie* pObject = (OVERLAY::ObjectPie*)p;

	//Record Header
	//RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_COMMON;
	//RecordHeader.nDataSize = sizeof(RecordData);

	//Write((BYTE*)&RecordHeader,sizeof(RecordHeader));

	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);
	pObject->GetSweepAngle(&RecordData.m_dSweepAngle[0],&RecordData.m_dSweepAngle[1]);

	if(!xmlDataSave(&RecordData, pLayer))
		AfxMessageBox("������ �������� ���߽��ϴ�");

	//Write((BYTE*)&RecordData,sizeof(RecordData));
}

void COverlayFileMgr::RecordArc(OVERLAY::OBJECT* p, CLayerStructure* pLayer)
{
	//OverlayFileRecordHeader	RecordHeader;
	OverlayFileRecordText RecordData;
	OVERLAY::ObjectArc* pObject = (OVERLAY::ObjectArc*)p;

	//Record Header
	//RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_COMMON;
	//RecordHeader.nDataSize = sizeof(RecordData);
	//Write((BYTE*)&RecordHeader,sizeof(RecordHeader));

	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);
	pObject->GetSweepAngle(&RecordData.m_dSweepAngle[0],&RecordData.m_dSweepAngle[1]);

	if(!xmlDataSave(&RecordData, pLayer))
		AfxMessageBox("������ �������� ���߽��ϴ�");

	//Write((BYTE*)&RecordData,sizeof(RecordData));
}

void COverlayFileMgr::RecordLinkedLine(OVERLAY::OBJECT* p)
{
	OverlayFileRecordHeader	RecordHeader;
	OverlayFileRecordCommon RecordData;
	OVERLAY::ObjectLinkedLine* pObject = (OVERLAY::ObjectLinkedLine*)p;

	//Record Header
	RecordHeader.eRecordType = OVERLAY_RECORD_TYPE_LINKED_LINE;
	RecordHeader.nDataSize = sizeof(RecordData);

	//Write((BYTE*)&RecordHeader,sizeof(RecordHeader));

	//Record Data
	RecordData.m_eType = pObject->GetType();
	RecordData.m_nPoints = (UINT)pObject->GetPoints();
	RecordData.m_nPointIndex = pObject->nPointIndex;
	RecordData.m_Property = pObject->Property;
//	RecordData.m_ObjectLinkedLineProperty = pObject->ObjectLinkedLineProperty;
	RecordData.m_nObjectID = pObject->nID;
	RecordData.nGroupID = pObject->GetGroupID();
	memcpy(RecordData.m_pt_out_line,pObject->pt_out_line,sizeof(RecordData.m_pt_out_line));
	memcpy(RecordData.m_pt,pObject->pt,sizeof(OVERLAY::Point)*RecordData.m_nPoints);

	RecordData.m_nLinkedLine_Start_ObjectID = pObject->nLinkedLine_Start_ID;
	RecordData.m_nLinkedLine_End_ObjectID = pObject->nLinkedLine_End_ID;

	RecordData.m_nLinkedLine_start_ObjectPointID = pObject->nObject_start_point_id;
	RecordData.m_nLinkedLine_end_ObjectPointID = pObject->nObject_end_point_id;

	//Write((BYTE*)&RecordData,sizeof(RecordData));
}

void COverlayFileMgr::RecordGroupInfo(OVERLAY::OBJECT* pObject, CLayerStructure* pLayer)
{
	CObjectGroupInfo*	pGroupInfo = NULL;
	pGroupInfo = pLayer->GetGroupInfo(pObject->GetGroupID());

	UINT nSize = 0;
	UINT nObjectIDInGroup = 0;
	UINT nGroupID = 0;

	if(pGroupInfo==NULL)
		return;
		//Write(&nSize,sizeof(nSize));
	else
	{
		nSize = pGroupInfo->Size();
		//Write(&nSize,sizeof(nSize));

		if(nSize>0)
		{
			nGroupID = pObject->GetGroupID();
			//Write(&nGroupID,sizeof(nGroupID));
		}

		for(UINT i=0; i<nSize; i++)
		{
			nObjectIDInGroup = pGroupInfo->GetObjectID(i);
			//Write(&nObjectIDInGroup,sizeof(nObjectIDInGroup));
		}
	}
}

BOOL COverlayFileMgr::LoadGroupInfo(CLayerStructure* pLayer)
{	
	UINT nSize = 0;
	UINT nObjectId = 0;
	UINT nGroupId = 0;
	OVERLAY::OBJECT* pObject = NULL;
	CObjectGroupInfo *pObjectGroupInfo = NULL;	
	
	if(Read(&nSize,sizeof(nSize))<=0)
		return FALSE;

	if(nSize>=OBJECT_PER_LAYER)
	{
		AfxMessageBox(_T("���������� �ùٸ��� �ʽ��ϴ�."));
		return FALSE;
	}
	if(nSize>0)
	{
		if(Read(&nGroupId,sizeof(nGroupId))<=0)
			return FALSE;
		pObjectGroupInfo = pLayer->GetGroupInfo(nGroupId);
		if(pObjectGroupInfo==NULL)
			pObjectGroupInfo = new CObjectGroupInfo;
	}
	else		
		return TRUE;
		
	for(UINT i=0; i<nSize; i++)
	{			
		if(Read(&nObjectId,sizeof(nObjectId))<=0)
			return FALSE;

		pObjectGroupInfo->AddObjectInGroup(nObjectId);		
	}

	pLayer->SetGroup(nGroupId,pObjectGroupInfo);
	
	return TRUE;
}
/*
BOOL COverlayFileMgr::Save(char* strFileName, int nStrLen, CLayerStructure* pLayer)
{
	CString strFilePath;
	CHAR	lpPath[512]={0,};
	GetCurrentDirectory(512,lpPath);
	sprintf(lpPath, "%s%s", lpPath, FILEPATH_SAVE_FOLDER);

	//CFileDialog dlgFile(FALSE, _T("*.ovl"), NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("������ ��������(*.ovl)|*.ovl|"), NULL);	
	CFileDialog dlgFile(FALSE, _T("*.ovl"),strFileName, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("������ ��������(*.ovl)|*.ovl|"), NULL);
	
	CFilePath overlaySavePath;
	overlaySavePath.SetWork(FILEPATH_SAVE_FOLDER);
	dlgFile.m_ofn.lpstrInitialDir= overlaySavePath.GetWork();// ������ ��������?
	//dlgFile.m_ofn.lpstrInitialDir= lpPath;// ������ ��������?

	if(dlgFile.DoModal() == IDOK)
	{
		strFilePath.Format(_T("%s"),dlgFile.GetPathName());
	}

	SetCurrentDirectory(lpPath);
		
	if(Open(strFilePath, CFile::modeWrite | CFile::modeCreate | CFile::typeBinary)==FALSE)
	{
			return FALSE;
	}

	if(pLayer==NULL)
	{
		Close();
		return FALSE;
	}
	
	OverlayFileHeader	FileHeader;
	// File Header 	
	FileHeader.SetFileName(pLayer->GetLayerName(), strlen(pLayer->GetLayerName()));
	Write((BYTE*)&FileHeader,sizeof(FileHeader));
	
	OVERLAY::OBJECT* pObject = pLayer->get_first_object();
	for(INT i=0; i<pLayer->NumberOfObjectInLayer(); i++)
	{
		// Save GroupInfo
		RecordGroupInfo(pObject, pLayer);

		//Record Header and Record Data
		switch(pObject->GetType())
		{
		case OVERLAY::TEXT:
			RecordText(pObject);

			break;
		case OVERLAY::IMAGE:
			RecordImage(pObject);

			break;

		case OVERLAY::ARC:
			RecordArc(pObject);

			break;
		case OVERLAY::PIE:
			RecordPie(pObject);

			break;
		case OVERLAY::LINKED_LINE:
		case OVERLAY::LINKED_MULTI_LINE:
		case OVERLAY::LINKED_CURVE:
		case OVERLAY::LINKED_MULTI_CURVE:
			RecordLinkedLine(pObject);

			break;
		default:
			RecordCommon(pObject);

			break;
		}		

		pObject = pLayer->get_next_object();
	}

	ULONGLONG nFileLength = CFile::GetLength();
	FileHeader.nFileSize =nFileLength;

	CFile::Seek(0,CFile::begin);
	Write((BYTE*)&FileHeader,sizeof(FileHeader));
	Close();
	return TRUE;
}
*/
BOOL COverlayFileMgr::Save(char* strFileName, int nStrLen, CLayerStructure* pLayer)
{
	CString strFilePath;
	CHAR	lpPath[512]={0,};
	GetCurrentDirectory(512,lpPath);
	sprintf(lpPath, "%s%s", lpPath, FILEPATH_SAVE_FOLDER);

	//CFileDialog dlgFile(FALSE, _T("*.ovl"), NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("������ ��������(*.ovl)|*.ovl|"), NULL);	
	CFileDialog dlgFile(FALSE, _T("*.xml"),strFileName, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("������ ��������(*.xml)|*.xml|"), NULL);
	
	CFilePath overlaySavePath;
	overlaySavePath.SetWork(FILEPATH_SAVE_FOLDER);
	dlgFile.m_ofn.lpstrInitialDir= overlaySavePath.GetWork();// ������ ��������?
	//dlgFile.m_ofn.lpstrInitialDir= lpPath;// ������ ��������?

	if(dlgFile.DoModal() == IDOK)
	{
		strFilePath.Format(_T("%s"),dlgFile.GetPathName());
	}

	SetCurrentDirectory(lpPath);
		
	if(Open(strFilePath, CFile::modeWrite | CFile::modeCreate)==FALSE)
	{
			return FALSE;
	}

	if(pLayer==NULL)
	{
		Close();
		return FALSE;
	}
	
	//OverlayFileHeader	FileHeader;
	 //File Header 	
	//FileHeader.SetFileName(pLayer->GetLayerName(), strlen(pLayer->GetLayerName()));
	//Write((BYTE*)&FileHeader,sizeof(FileHeader));
	CString _header;
	_header = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
	Write(_header, _header.GetLength());


	OVERLAY::OBJECT* pObject = pLayer->get_first_object();
	for(INT i=0; i<pLayer->NumberOfObjectInLayer(); i++)
	{
		// Save GroupInfo
		RecordGroupInfo(pObject, pLayer);

		//Record Header and Record Data
		switch(pObject->GetType())
		{
		case OVERLAY::TEXT:
			RecordText(pObject, pLayer);
			break;

		//case OVERLAY::IMAGE:
		//	RecordImage(pObject);
		//	break;

		case OVERLAY::ARC:				// ��ȣ
			RecordArc(pObject, pLayer);
			break;

		case OVERLAY::PIE:				// ��ä��, 
			RecordPie(pObject, pLayer);
			break;

		//case OVERLAY::LINKED_LINE:
		//case OVERLAY::LINKED_MULTI_LINE:
		//case OVERLAY::LINKED_CURVE:
		//case OVERLAY::LINKED_MULTI_CURVE:
		//	RecordLinkedLine(pObject);
		//	break;

		default: // ����, ��, �ﰢ��, �簢��
			RecordCommon(pObject, pLayer);
			break;
		}		

		pObject = pLayer->get_next_object();
	}

	//ULONGLONG nFileLength = CFile::GetLength();
	//FileHeader.nFileSize =nFileLength;

	//CFile::Seek(0,CFile::begin);
	//Write((BYTE*)&FileHeader,sizeof(FileHeader));
	Close();
	return TRUE;
}


BOOL COverlayFileMgr::Load(char* strFileName, int nStrLen)
{	
	int i = 0;

	if(Open(strFileName, CFile::modeRead  | CFile::typeBinary)==FALSE)
	{
		return FALSE;
	}

	OverlayFileHeader	FileHeader;

	// 1. Read File Header
	Read(&FileHeader,sizeof(OverlayFileHeader));
	if(m_pOverlayMain->AddLayer(FileHeader.m_szLayerName, strlen(FileHeader.m_szLayerName))==FALSE)
	{
		Close();
		AfxMessageBox(_T("���̻� ���̾ �߰��� �� �����ϴ�."));
		return FALSE;
	}

	if(CheckValidation(FileHeader)==FALSE)
	{		
		m_pOverlayMain->DeleteLayer(0);
		AfxMessageBox(_T("������ ������ �����ϴ�."));
		Close();
		return FALSE;
	}

	while(1)
	{
		if(LoadGroupInfo(m_pOverlayMain->GetLayer(0))==FALSE)
			break;
		
		// 2. Record Header 
		OverlayFileRecordHeader RecordHeader;
		if( Read(&RecordHeader,sizeof(OverlayFileRecordHeader)) < sizeof(OverlayFileRecordHeader))
		{			
			Close();
			m_pOverlayMain->DeleteLayer(0);
			AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
			return FALSE;
		}
		
		// 3. Record Data
		switch(RecordHeader.eRecordType)
		{
		case OVERLAY_RECORD_TYPE_COMMON:
			//if(LoadCommon()==FALSE)
			//{							
			//	Close();
			//	m_pOverlayMain->DeleteLayer(0);
			//	AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
			//	return FALSE;
			//}

			break;
		case OVERLAY_RECORD_TYPE_TEXT:
			//if(LoadText()==FALSE)
			//{							
			//	Close();
			//	m_pOverlayMain->DeleteLayer(0);
			//	AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
			//	return FALSE;
			//}

			break;
		case OVERLAY_RECORD_TYPE_IMAGE:
			if(LoadImage()==FALSE)
			{							
				Close();
				m_pOverlayMain->DeleteLayer(0);
				AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
				return FALSE;
			}
			
			break;		
		case OVERLAY_RECORD_TYPE_LINKED_LINE:				
			if(LoadLinkedLine()==FALSE)
			{							
				Close();
				m_pOverlayMain->DeleteLayer(0);
				AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
				return FALSE;
			}

			break;
		default:			
			Close();
			m_pOverlayMain->DeleteLayer(0);
			AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
			return  FALSE;//Seek(RecordHeader.nDataSize,CFile::current);
		}

	}

	//������ ���ἱ ����.
	CompleteLinkedLine();
	Close();
	return TRUE;
}

WCHAR* COverlayFileMgr::strtoWCHAR(std::string in)
{
	WCHAR *wcharout = new WCHAR[1023];
	size_t* sizeOut = new size_t;
	size_t sizeInWord = 256;

	const char *Cstr = in.c_str();
	mbstowcs_s(sizeOut, wcharout, sizeInWord, Cstr,  strlen(Cstr)+1);

	return wcharout;
}

BOOL COverlayFileMgr::LoadXML(char* filename, int nStrLen)
{
	string		strOid, strGid, strNm, strDc, strDe, strSh, strLck, strSt, strPt, strCt, strColor;
	string		strText, strFont, strSize, strCol, strBold, strItalic, strFillMethod, strFillCol;
	string		strSarrow, strEarrow, strDashStyle, strLineStyle, strLineWidth, strRotate, strRotate1, strRotate2, strRotate3;
	string		str_2525b, strSymbol, strCoord, strSymsize;
	CString		str_value;
	CString		str_path;
	int			loop = 0;
	
	//OverlayFileRecordCommon RecordData_common;
	OverlayFileRecordText RecordData_common;

	//int		nMaxItem = 0;
	//int count = 0;
	
	str_path.Format("%s", filename);
	if(m_markup.Load(str_path.GetBuffer(str_path.GetLength())) == TRUE)
	{
		m_markup.ResetMainPos();
		if(m_markup.FindElem("ovi")==TRUE)
		{

		}
		
		m_markup.IntoElem();
		while(m_markup.FindElem("ovs")==TRUE)
		{
			str_value = m_markup.GetAttrib("oid");
			if(str_value.GetLength() > 0)
				strOid = str_value.GetBuffer(str_value.GetLength());

			str_value = m_markup.GetAttrib("gid");
			if(str_value.GetLength() > 0)
				strGid = str_value.GetBuffer(str_value.GetLength());

			str_value = m_markup.GetAttrib("nm");
			if(str_value.GetLength() > 0)
				strNm = str_value.GetBuffer(str_value.GetLength());

			m_markup.IntoElem();
			if(m_markup.FindElem("geo")==TRUE )
			{
				str_value = m_markup.GetAttrib("pt");
				if(str_value.GetLength()>0)
					strPt = str_value.GetBuffer(str_value.GetLength());

				str_value = m_markup.GetAttrib("ct");
				if(str_value.GetLength()>0)
					strCt = str_value.GetBuffer(str_value.GetLength());
			}
			if(m_markup.FindElem("lp")==TRUE )
			{
				str_value = m_markup.GetAttrib("lc");
				if(str_value.GetLength()>0)
				{
					strColor = str_value.GetBuffer(str_value.GetLength());
				}

				str_value = m_markup.GetAttrib("lw");
				if(str_value.GetLength()>0)
				{
					strLineWidth = str_value.GetBuffer(str_value.GetLength());
				}

				m_markup.IntoElem();
				if(m_markup.FindElem("lcs")==TRUE )
				{
					str_value = m_markup.GetAttrib("cs");
					if(str_value.GetLength()>0)
					{
						strSarrow = str_value.GetBuffer(str_value.GetLength());
					}
				}
			
				if(m_markup.FindElem("lce")==TRUE )
				{
					str_value = m_markup.GetAttrib("cs");
					if(str_value.GetLength()>0)
					{
						strEarrow = str_value.GetBuffer(str_value.GetLength());
					}
				}

				if(m_markup.FindElem("ds")==TRUE )
				{
					str_value = m_markup.GetAttrib("cd");
					if(str_value.GetLength()>0)
					{
						strDashStyle = str_value.GetBuffer(str_value.GetLength());
					}

					str_value = m_markup.GetAttrib("ds");
					if(str_value.GetLength()>0)
					{
						strLineStyle = str_value.GetBuffer(str_value.GetLength());
					}
				}
				if(m_markup.FindElem("hb")==TRUE )
				{

				}
				if(m_markup.FindElem("pgb")==TRUE )
				{

				}
				if(m_markup.FindElem("lgb")==TRUE )
				{

				}
				m_markup.OutOfElem();
			}
			//m_markup.OutOfElem();

			//m_markup.IntoElem();
			if(m_markup.FindElem("fp")==TRUE )
			{
				str_value = m_markup.GetAttrib("ft");
				if(str_value.GetLength()>0)
				{
					strFillMethod = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("fc");
				if(str_value.GetLength()>0)
				{
					strFillCol = str_value.GetBuffer(str_value.GetLength());
				}
				
				m_markup.IntoElem();
				if(m_markup.FindElem("hb")==TRUE )
				{
					
				}
				if(m_markup.FindElem("pgb")==TRUE )
				{

				}
				if(m_markup.FindElem("lgb")==TRUE )
				{

				}
				m_markup.OutOfElem();
			}
			if(m_markup.FindElem("tp")==TRUE )
			{
				str_value = m_markup.GetAttrib("tx");
				if(str_value.GetLength()>0)
				{
					strText = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("fn");
				if(str_value.GetLength()>0)
				{
					strFont = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("fs");
				if(str_value.GetLength()>0)
				{
					strSize = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("tc");
				if(str_value.GetLength()>0)
				{
					strCol = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("bd");
				if(str_value.GetLength()>0)
				{
					strBold = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("it");
				if(str_value.GetLength()>0)
				{
					strItalic = str_value.GetBuffer(str_value.GetLength());
				}
			}
			if(m_markup.FindElem("spt")==TRUE )
			{

			}
			if(m_markup.FindElem("srt")==TRUE )
			{
				str_value = m_markup.GetAttrib("rot");
				if(str_value.GetLength()>0)
				{
					strRotate = str_value.GetBuffer(str_value.GetLength());
				}
			}
			if(m_markup.FindElem("sel")==TRUE )
			{
				str_value = m_markup.GetAttrib("rot");
				if(str_value.GetLength()>0)
				{
					strRotate1 = str_value.GetBuffer(str_value.GetLength());
				}
			}
			if(m_markup.FindElem("sar")==TRUE )
			{
				str_value = m_markup.GetAttrib("rot");
				if(str_value.GetLength()>0)
				{
					strRotate2 = str_value.GetBuffer(str_value.GetLength());
				}
			}
			if(m_markup.FindElem("spl")==TRUE )
			{
				str_value = m_markup.GetAttrib("rot");
				if(str_value.GetLength()>0)
				{
					strRotate3 = str_value.GetBuffer(str_value.GetLength());
				}
			}
			if(m_markup.FindElem("sts")==TRUE )
			{
				CString strXml;
				CC4IMapDoc *pDoc = (CC4IMapDoc*)((CMainFrame *)AfxGetMainWnd())->GetActiveDocument();

				strXml = m_markup.GetSubDoc();
/*
				str_value = m_markup.GetAttrib("symbol");
				if(str_value.GetLength()>0)
				{
					strSymbol = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("coord");
				if(str_value.GetLength()>0)
				{
					strCoord = str_value.GetBuffer(str_value.GetLength());
				}
				str_value = m_markup.GetAttrib("symsize");
				if(str_value.GetLength()>0)
				{
					strSymsize = str_value.GetBuffer(str_value.GetLength());
				}
*/
				//strXml = m_xml.SetSTS(&RecordData_common);
				// 
				// 
				//CTest_OverItem::SetOverlayXmlString(pDoc->m_parOverItems, strXml);
			}

	
			CString vname = strNm.c_str(); 
			if(vname == "LINE")
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::LINE;			// ����
			else if(vname == "RECT")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::RECT_TYPE;			// �簢��
				double rectRotate = atof(strRotate.c_str());
				RecordData_common.m_Property.dAngle = rectRotate;
			}
			else if(vname == "TRIANGLE")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::TRIANGLE;		// �ﰢ��
				double rectRotate = atof(strRotate.c_str());
				RecordData_common.m_Property.dAngle = rectRotate;
			}
			else if(vname == "PIE")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::PIE;			// ����(��ä��)
				double rectRotate2 = atof(strRotate2.c_str());
				RecordData_common.m_Property.dAngle = rectRotate2;
			}
			else if(vname == "ELLIPSE")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::ELLIPSE;		// Ÿ��	
				double rectRotate1 = atof(strRotate1.c_str());
				RecordData_common.m_Property.dAngle = rectRotate1;
			}
			else if(vname == "ARC")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::ARC;			// ��ȣ
				double rectRotate2 = atof(strRotate2.c_str());
				RecordData_common.m_Property.dAngle = rectRotate2;
			}
			else if(vname == "TEXT")
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::TEXT;			// �ؽ�Ʈ
			else if(vname == "POLYGON")
			{
				RecordData_common.m_eType = OVERLAY::OBJECT_TYPE::POLYGON;			// �ؽ�Ʈ
				double rectRotate3 = atof(strRotate3.c_str());
				RecordData_common.m_Property.dAngle = rectRotate3;
			}

			CString outTmp = strPt.c_str();
			int pos3=0,pos4=0;
			int k1 =0;
			while(1)//�ټ��Ľ� 
			{
				CString str = outTmp.Tokenize(_T("|"),pos3);
				if(pos3 == -1)	break;
				double lat3,lon3;
				lon3 = atof(str.Tokenize(_T(","),pos4));
				lat3 = atof(str.Tokenize(_T(","),pos4));
				RecordData_common.m_pt[k1].ReSetLatLong(lon3, lat3);
				pos4=0;
				k1++;
			}

			// �ﰢ�� 3, ���� 4, Ÿ�� 2, ��ȣ 4,
			RecordData_common.m_nPoints = k1;
			RecordData_common.m_nObjectID = 1;
			RecordData_common.m_nPointIndex = k1;

			WCHAR *KK;

			USES_CONVERSION;
			KK = A2W(strText.c_str());
			//KK = strtoWCHAR(strText);
			wcsncpy(RecordData_common.m_Text, KK, 512);

			double linewidth = atof(strLineWidth.c_str());
			RecordData_common.m_Property.dLineWidth = linewidth;

			int dashstyle = atoi(strDashStyle.c_str());
			switch(dashstyle)
			{
			case 0:
				RecordData_common.m_Property.eDashStyle = OVERLAY::DashCap::DashCapFlat;
				break;
			case 1:
				RecordData_common.m_Property.eDashStyle = OVERLAY::DashCap::DashCapRound;
				break;
			case 2:
				RecordData_common.m_Property.eDashStyle = OVERLAY::DashCap::DashCapTriangle;
				break;
			}

			int linestyle = atoi(strLineStyle.c_str());
			switch(linestyle)
			{
			case 0:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::Solid;
				break;
			case 1:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::Dash;
				break;
			case 2:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::Dot;
				break;
			case 3:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::DashDot;
				break;
			case 4:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::DashDotDot;
				break;
			case 5:
				RecordData_common.m_Property.eLineStyle = OVERLAY::LINE_STYLE::Custom;
				break;
			}
			

			float tsize = atof(strSize.c_str());
			RecordData_common.m_dFontSize = tsize;

			CString tmpc = strCol.c_str();
			CString tmpc1 = tmpc.Mid(1);

			unsigned long c = strtoul(tmpc1, NULL, 16);
			RecordData_common.m_FontColor = c;

			int font = atoi(strFont.c_str());
			switch(font)
			{
			case 0:
				RecordData_common.m_eFamilyName = OVERLAY::FAMILY_NAME_GOOLIM;
				break;
			case 1:
				RecordData_common.m_eFamilyName = OVERLAY::FAMILY_NAME_GODICK;
				break;
			case 2:
				RecordData_common.m_eFamilyName = OVERLAY::FAMILY_NAME_DODWOOM;
				break;
			case 3:
				RecordData_common.m_eFamilyName = OVERLAY::FAMILY_NAME_BATANG;
				break;
			}

			// ���� ����, ����
			int fontstyle = atoi(strBold.c_str());
			switch(fontstyle)
			{
			case 0:
				RecordData_common.m_eFontStyle = FontStyleRegular;
				break;
			case 1:
				RecordData_common.m_eFontStyle = FontStyleBold;
				break;
			case 2:
				RecordData_common.m_eFontStyle = FontStyleItalic;
				break;
			case 3:
				RecordData_common.m_eFontStyle = FontStyleBoldItalic;
				break;
			case 4:
				RecordData_common.m_eFontStyle = FontStyleUnderline;
				break;
			case 5:
				RecordData_common.m_eFontStyle = FontStyleStrikeout;
				break;
			}

			// ������ �ƿ�Ʈ ���� �����Ϳ� ���� ������ �׷��� �ʿ� ����.
			//strText
			//CString strTemp = str_2525b.c_str();
			//int pos=0,pos2=0;
			//int k =0;
			//while(1)//�ټ��Ľ� 
			//{
			//	CString str = strTemp.Tokenize(_T("|"),pos);
			//	if(pos == -1)	break;
			//	double lat3,lon3;
			//	lon3 = atof(str.Tokenize(_T(","),pos2));
			//	lat3 = atof(str.Tokenize(_T(","),pos2));
			//	RecordData_common.m_pt_out_line[k].ReSetLatLong(lon3, lat3);
			//	pos2=0;
			//	k++;
			//}

			int sarrow = atoi(strSarrow.c_str());
			RecordData_common.m_Property.nStartLineArrowStyle = sarrow;

			int earrow = atoi(strEarrow.c_str());
			RecordData_common.m_Property.nEndLineArrowStyle = earrow;


			CString tmp = strColor.c_str();
			CString tmp1 = tmp.Mid(1);

			unsigned long j = strtoul(tmp1, NULL, 16);
			RecordData_common.m_Property.LineColor = j;


			int fillmethod = atoi(strFillMethod.c_str());
			RecordData_common.m_Property.FillStyle = fillmethod;

			CString tmp2 = strFillCol.c_str();
			CString tmp3 = tmp2.Mid(1);

			unsigned long jj = strtoul(tmp3, NULL, 16);
			RecordData_common.m_Property.FillColor = jj;


			if(RecordData_common.m_eType == OVERLAY::OBJECT_TYPE::PIE ||
				RecordData_common.m_eType == OVERLAY::OBJECT_TYPE::ARC)
			{
				RecordData_common.m_dSweepAngle[0] = 0.000;
				RecordData_common.m_dSweepAngle[1] = 45.000;
			}
			if(m_pOverlayMain->AddLayer((char*)strGid.c_str(), strlen(strGid.c_str()))==FALSE)
			{
				Close();
				return FALSE;
			}
			//if(CheckValidation(FileHeader)==FALSE)
			//{		
				//m_pOverlayMain->DeleteLayer(0);
				//AfxMessageBox(_T("������ ������ �����ϴ�."));
				//Close();
				//return FALSE;
			//}

			//while(1)
			//{
				//if(LoadGroupInfo(m_pOverlayMain->GetLayer(0))==FALSE)
				//	break;
		
				// 2. Record Header 
				//OverlayFileRecordHeader RecordHeader;
				//if( Read(&RecordHeader,sizeof(OverlayFileRecordHeader)) < sizeof(OverlayFileRecordHeader))
				//{			
				//	Close();
				//	m_pOverlayMain->DeleteLayer(0);
				//	AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
				//	return FALSE;
				//}
		
				// 3. Record Data
				//switch(RecordHeader.eRecordType)
				switch(RecordData_common.m_eType)
				{
				case OVERLAY::OBJECT_TYPE::LINE:
				case OVERLAY::OBJECT_TYPE::RECT_TYPE:
				case OVERLAY::OBJECT_TYPE::ELLIPSE:
				case OVERLAY::OBJECT_TYPE::PIE:
				case OVERLAY::OBJECT_TYPE::TRIANGLE:
				case OVERLAY::OBJECT_TYPE::ARC:
				case OVERLAY::OBJECT_TYPE::POLYGON:
					if(LoadCommon(RecordData_common)==FALSE)
					{							
						Close();
						m_pOverlayMain->DeleteLayer(0);
						AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
						return FALSE;
					}
					break;
				case OVERLAY::OBJECT_TYPE::TEXT:
					if(LoadText(RecordData_common)==FALSE)
					{							
						Close();
						m_pOverlayMain->DeleteLayer(0);
						AfxMessageBox(_T("���� ������ �ùٸ��� �ʽ��ϴ�."));
						return FALSE;
					}
					break;
				}
				m_markup.OutOfElem();
			//}
			}
			//������ ���ἱ ����.
			//CompleteLinkedLine();
			//Close();

		}
		else
			return FALSE;
	
	//CompleteLinkedLine();
	//Close();

	return TRUE;
}


BOOL COverlayFileMgr::LoadCommon(OverlayFileRecordCommon RecordData_common)
{	
	//OverlayFileRecordCommon RecordData_common;
	OVERLAY::OBJECT* pObject = NULL;	
	OVERLAY::ObjectArc* pObjectArc = NULL;
	OVERLAY::ObjectPie* pObjectPie = NULL;

	//TRACE("File Current Postion : %d\n",CFile::GetPosition());
	//if( Read(&RecordData_common,sizeof(RecordData_common)) < sizeof(OverlayFileRecordCommon))
	//{
	//	return FALSE;
	//}
	
	pObject = CreateObject(RecordData_common.m_eType);
	if(pObject==NULL)
	{
		return FALSE;
	}

	pObject->nID = RecordData_common.m_nObjectID;
	pObject->SetGroup(RecordData_common.nGroupID);

	if(RecordData_common.m_nPointIndex>=MAX_POINTS)
	{
		SAFE_DELETE(pObject);
		return FALSE;
	}
	pObject->nPointIndex = RecordData_common.m_nPointIndex;
//	memcpy(&pObject->ObjectLinkedLineProperty,&RecordData_common.m_ObjectLinkedLineProperty,sizeof(RecordData_common.m_ObjectLinkedLineProperty));
	memcpy(&pObject->Property,&RecordData_common.m_Property,sizeof(RecordData_common.m_Property));
	//memcpy(pObject->pt,RecordData_common.m_pt,sizeof(OVERLAY::Point)*RecordData_common.m_nPoints);
	//memcpy(pObject->pt_out_line, RecordData_common.m_pt_out_line, sizeof(RecordData_common.m_pt_out_line));
	UINT i=0;
	for( i=0; i<OVERLAY::POINTS_OF_OBJECT_OUTLINE; i++)
		pObject->pt_out_line[i].SetLatLong(RecordData_common.m_pt_out_line[i].Lat(),RecordData_common.m_pt_out_line[i].Lng());
	for( i=0; i<RecordData_common.m_nPoints; i++)
		pObject->pt[i].SetLatLong(RecordData_common.m_pt[i].Lat(),RecordData_common.m_pt[i].Lng());

	switch(pObject->GetType())
	{
	case OVERLAY::ARC:
		pObjectArc = (OVERLAY::ObjectArc*)pObject;
		pObjectArc->SetSweepAngle(RecordData_common.m_dSweepAngle[0],RecordData_common.m_dSweepAngle[1]);
	
		break;
	case OVERLAY::PIE:
		pObjectPie = (OVERLAY::ObjectPie*)pObject;
		pObjectPie->SetSweepAngle(RecordData_common.m_dSweepAngle[0],RecordData_common.m_dSweepAngle[1]);

		break;
	}

	m_pOverlayMain->AddObject(pObject);

	return TRUE;

}

//IMAGE_FILE_DIRECTORY
BOOL COverlayFileMgr::LoadImage()
{	
	OverlayFileRecordImage	RecordData_image;
	OVERLAY::OBJECT* pObject = NULL;
	OVERLAY::ObjectImage* pObjectImage = NULL;

	TRACE("File Current Postion : %d\n",CFile::GetPosition());
	if( Read(&RecordData_image,sizeof(RecordData_image)) < sizeof(OverlayFileRecordImage))
	{
		return FALSE;
	}

	pObject = CreateObject(RecordData_image.m_eType);
	if(pObject==NULL)
	{
		return FALSE;
	}

	pObject->nID = RecordData_image.m_nObjectID;
	pObject->SetGroup(RecordData_image.nGroupID);

//	memcpy(&pObject->ObjectLinkedLineProperty,&RecordData_image.m_ObjectLinkedLineProperty,sizeof(RecordData_image.m_ObjectLinkedLineProperty));
	memcpy(&pObject->Property,&RecordData_image.m_Property,sizeof(RecordData_image.m_Property));
	
	UINT i=0;
	for( i=0; i<OVERLAY::POINTS_OF_OBJECT_OUTLINE; i++)
		pObject->pt_out_line[i].SetLatLong(RecordData_image.m_pt_out_line[i].Lat(),RecordData_image.m_pt_out_line[i].Lng());
	for( i=0; i<RecordData_image.m_nPoints; i++)
		pObject->pt[i].SetLatLong(RecordData_image.m_pt[i].Lat(),RecordData_image.m_pt[i].Lng());

	pObjectImage = (OVERLAY::ObjectImage*) pObject;

	memset(pObjectImage->m_strImageFileName,0,sizeof(pObjectImage->m_strImageFileName));
	memcpy(pObjectImage->m_strImageFileName, RecordData_image.m_szImageFileName,strlen(RecordData_image.m_szImageFileName));

	// �̹��� ���� ����.
	FILE* hImageFile = NULL;
	DWORD nCurrentPosition = (DWORD)CFile::GetPosition();
//	hImageFile = fopen(pObjectImage->m_strImageFileName,"rb");
	char lpBuffer[1024];//�߰� 
	GetCurrentDirectory(1024, lpBuffer);//�߰�
	memcpy(lpBuffer+strlen(lpBuffer),pObjectImage->m_strImageFileName,strlen(pObjectImage->m_strImageFileName)+1);//�߰�
	hImageFile = fopen(lpBuffer,_T("wb"));//�߰� 

// 
// 
// 	DWORD nCurrentPosition = (DWORD)CFile::GetPosition();
// 	if(hImageFile>0)
// 	{
// 		TRACE("File Current Postion : %d\n",CFile::GetPosition());
// 		CFile::Seek(RecordData_image.m_nImageSize,CFile::current);
// 		fclose(hImageFile);
// 		TRACE("File Current Postion : %d\n",CFile::GetPosition());
// 	}
// 	else
// 	{
// 		int nCount=sizeof(RecordData_image.m_szImageFileName);
// 		for(i=nCount-1; i>=0; i--)
// 		{
// 			if(RecordData_image.m_szImageFileName[i]=='\\' || RecordData_image.m_szImageFileName[i]=='/')
// 			{
// 				char* pImageFileName = pObjectImage->m_strImageFileName;
// 				char lpBuffer[1024];
// 				GetCurrentDirectory(1024,lpBuffer);
// 				memcpy(pImageFileName,lpBuffer,strlen(lpBuffer));
// 				pImageFileName += strlen(lpBuffer);
// 				memcpy(pImageFileName,IMAGE_FILE_DIRECTORY,strlen(IMAGE_FILE_DIRECTORY));
// 				pImageFileName += strlen(IMAGE_FILE_DIRECTORY);
// 				memcpy(pImageFileName,&RecordData_image.m_szImageFileName[i+1],strlen(&RecordData_image.m_szImageFileName[i+1]));
// 				pImageFileName += strlen(&RecordData_image.m_szImageFileName[i+1]);
// 				pImageFileName++;
// 				*pImageFileName = '\0';
// 				break;
// 			}
// 			
// 		}
// 
// 		//hImageFile = fopen(pObjectImage->m_strImageFileName,"a");
// 		hImageFile = fopen(&RecordData_image.m_szImageFileName[i+1],_T("wb"));

		int nImageSizeCount=0;
		int nImageSizeRemain=0;

		BYTE ImageBuffer[1024];
		memset(ImageBuffer,0,sizeof(ImageBuffer));
		if(hImageFile>0)
		{
			memset(pObjectImage->m_strImageFileName,0,sizeof(pObjectImage->m_strImageFileName));
			memcpy(pObjectImage->m_strImageFileName,&RecordData_image.m_szImageFileName[i+1],sizeof(RecordData_image.m_szImageFileName)-(i+1));
			nImageSizeCount = RecordData_image.m_nImageSize/sizeof(ImageBuffer);
			nImageSizeRemain = RecordData_image.m_nImageSize%sizeof(ImageBuffer);

			for(int i=0; i<nImageSizeCount; i++)
			{
				Read((BYTE*)ImageBuffer, sizeof(ImageBuffer));
				fwrite((BYTE*)ImageBuffer, sizeof(ImageBuffer), 1, hImageFile);
			}

			if(nImageSizeRemain>0)
			{
				Read((BYTE*)ImageBuffer, nImageSizeRemain);
				fwrite((BYTE*)ImageBuffer, nImageSizeRemain, 1, hImageFile);
			}
			
			fclose(hImageFile);
		}
// 		else
// 			AfxMessageBox(_T("�̹��� ������ ���������� �������� �ʾҽ��ϴ�."));
// 
// 	}
	m_pOverlayMain->AddObject(pObject);

	CFile::Seek(nCurrentPosition,CFile::begin);
	CFile::Seek(RecordData_image.m_nImageSize,CFile::current);
	return TRUE;	
}

BOOL COverlayFileMgr::LoadText(OverlayFileRecordText RecordData_text)
{
	//OverlayFileRecordText	RecordData_text;	
	OVERLAY::OBJECT* pObject = NULL;	
	OVERLAY::ObjectText* pObjectText = NULL;

	//if( Read(&RecordData_text,sizeof(RecordData_text)) < sizeof(OverlayFileRecordText))
	//{
	//	return FALSE;
	//}

	pObject = CreateObject(RecordData_text.m_eType);

	if(pObject==NULL)
	{
		return FALSE;
	}

	pObject->nID = RecordData_text.m_nObjectID;			
	pObject->SetGroup(RecordData_text.nGroupID);

//	memcpy(&pObject->ObjectLinkedLineProperty,&RecordData_text.m_ObjectLinkedLineProperty,sizeof(RecordData_text.m_ObjectLinkedLineProperty));
	memcpy(&pObject->Property,&RecordData_text.m_Property,sizeof(RecordData_text.m_Property));			
		
	UINT i=0;
	for( i=0; i<OVERLAY::POINTS_OF_OBJECT_OUTLINE; i++)
		pObject->pt_out_line[i].SetLatLong(RecordData_text.m_pt_out_line[i].Lat(),RecordData_text.m_pt_out_line[i].Lng());
	for( i=0; i<RecordData_text.m_nPoints; i++)
		pObject->pt[i].SetLatLong(RecordData_text.m_pt[i].Lat(),RecordData_text.m_pt[i].Lng());

	pObjectText = (OVERLAY::ObjectText*) pObject;
	pObjectText->SetSize(RecordData_text.m_dFontSize);
	pObjectText->SetFontFamilyName(RecordData_text.m_eFamilyName);
	pObjectText->SetFontUnit(RecordData_text.m_eUnit);
	pObjectText->SetColor(RecordData_text.m_FontColor);
	pObjectText->SetFontStyle(RecordData_text.m_eFontStyle);
	pObjectText->SetText(RecordData_text.m_Text,sizeof(RecordData_text.m_Text));

	m_pOverlayMain->AddObject(pObject);

	return TRUE;
}

BOOL COverlayFileMgr::LoadLinkedLine()
{	
	OverlayFileRecordCommon RecordData_common;
	
	OVERLAY::OBJECT* pObject = NULL;
	OVERLAY::ObjectLinkedLine* pObjectLinkedLine = NULL;

	if( Read(&RecordData_common,sizeof(RecordData_common)) < sizeof(OverlayFileRecordCommon))
	{
		return FALSE;
	}
	
	pObject = CreateObject(RecordData_common.m_eType);
	if(pObject==NULL)
	{
		return FALSE;
	}

	pObject->nID = RecordData_common.m_nObjectID;
	pObject->SetGroup(RecordData_common.nGroupID);

	if(RecordData_common.m_nPointIndex>=MAX_POINTS)
	{
		SAFE_DELETE(pObject);
		return FALSE;
	}
	pObject->nPointIndex = RecordData_common.m_nPointIndex;
//	memcpy(&pObject->ObjectLinkedLineProperty,&RecordData_common.m_ObjectLinkedLineProperty,sizeof(RecordData_common.m_ObjectLinkedLineProperty));
	memcpy(&pObject->Property,&RecordData_common.m_Property,sizeof(RecordData_common.m_Property));
	
	UINT i=0;
	for( i=0; i<OVERLAY::POINTS_OF_OBJECT_OUTLINE; i++)
		pObject->pt_out_line[i].SetLatLong(RecordData_common.m_pt_out_line[i].Lat(),RecordData_common.m_pt_out_line[i].Lng());
	for( i=0; i<RecordData_common.m_nPoints; i++)
		pObject->pt[i].SetLatLong(RecordData_common.m_pt[i].Lat(),RecordData_common.m_pt[i].Lng());

	pObjectLinkedLine = (OVERLAY::ObjectLinkedLine*)pObject;

	pObjectLinkedLine->nLinkedLine_Start_ID = RecordData_common.m_nLinkedLine_Start_ObjectID;
	pObjectLinkedLine->nLinkedLine_End_ID = RecordData_common.m_nLinkedLine_End_ObjectID;
	pObjectLinkedLine->nObject_start_point_id = RecordData_common.m_nLinkedLine_start_ObjectPointID;
	pObjectLinkedLine->nObject_end_point_id = RecordData_common.m_nLinkedLine_end_ObjectPointID;		
				
	m_pOverlayMain->AddObject(pObject);

	return TRUE;
}

void COverlayFileMgr::CompleteLinkedLine()
{
	CLayerStructure* pLayer = m_pOverlayMain->GetLayer(0);
	if(pLayer==NULL)
		return;

	OVERLAY::OBJECT* pObject = pLayer->get_first_object();
	OVERLAY::OBJECT* pStartObject = NULL;	// ���ἱ�� �̾��� ����.
	OVERLAY::OBJECT* pEndObject = NULL;		// ���ἱ�� �̾��� ����.
	OVERLAY::ObjectLinkedLine* pLinkedLine = NULL;

	while(pObject!=NULL)
	{		
		if( pObject->GetType()==OVERLAY::LINKED_LINE ||
			pObject->GetType()==OVERLAY::LINKED_MULTI_LINE ||
			pObject->GetType()==OVERLAY::LINKED_CURVE ||
			pObject->GetType()==OVERLAY::LINKED_MULTI_CURVE
			)
		{
			pLinkedLine = (OVERLAY::ObjectLinkedLine*)pObject;
			
			pStartObject = m_pOverlayMain->SelectedObject(pLinkedLine->nLinkedLine_Start_ID);
			pEndObject = m_pOverlayMain->SelectedObject(pLinkedLine->nLinkedLine_End_ID);

			if(pStartObject!=NULL && pEndObject!=NULL)
			{
				//�ٰ��� �Ǵ� �Ϲݵ����� �����ϸ�, �ٰ����ϰ�� ������ �̷�� ���� Index(ID)�� GENERAL_POINTS�κ��� ���۵ȴ�.
				if(pLinkedLine->nObject_start_point_id>=OVERLAY::GENERAL_POINTS)
					pLinkedLine->SetLinkPoint(0, &pStartObject->pt[pLinkedLine->nObject_start_point_id-OVERLAY::GENERAL_POINTS]);
				else
					pLinkedLine->SetLinkPoint(0, &pStartObject->pt_out_line[pLinkedLine->nObject_start_point_id]);

				if(pLinkedLine->nObject_end_point_id>=OVERLAY::GENERAL_POINTS)
					pLinkedLine->SetLinkPoint(pLinkedLine->GetPoints()-1, &pEndObject->pt[pLinkedLine->nObject_end_point_id-OVERLAY::GENERAL_POINTS]);
				else
					pLinkedLine->SetLinkPoint(pLinkedLine->GetPoints()-1, &pEndObject->pt_out_line[pLinkedLine->nObject_end_point_id]);

				pStartObject->ObjectLinkedLineProperty.AddObjectID(pLinkedLine->nID);
				pEndObject->ObjectLinkedLineProperty.AddObjectID(pLinkedLine->nID);				
			}
		}

		pObject = pLayer->get_next_object();
	}
	m_pOverlayMain->DrawEditlayer();
}

OVERLAY::OBJECT* COverlayFileMgr::CreateObject(OVERLAY::OBJECT_TYPE eObjectType, char* strImageFileName, int nStrImageFileNameLen)
{
	OVERLAY::OBJECT	*pObject		= NULL;
	OVERLAY::ObjectEllipse			*pEllipse			= NULL;
	OVERLAY::ObjectArc				*pArc				= NULL;
	OVERLAY::ObjectPie				*pPie				= NULL;
	OVERLAY::ObjectTriangle 		*pTriangle			= NULL;
	OVERLAY::ObjectDiamond			*pDiamond			= NULL;
	OVERLAY::ObjectRect				*pRect				= NULL;
	OVERLAY::ObjectPentagon			*pPentagon			= NULL;
	OVERLAY::ObjectRoundRect		*pRoundRect			= NULL;
	OVERLAY::ObjectSixAngle			*pSixAngle			= NULL;
	OVERLAY::ObjectEightAngle		*pEightAngle		= NULL;
	OVERLAY::ObjectPolygon			*pPolygon			= NULL;
	OVERLAY::ObjectPolyLine			*pPolyLine			= NULL;
	OVERLAY::ObjectLine				*pLine				= NULL;
	OVERLAY::ObjectText				*pText				= NULL;
	OVERLAY::ObjectImage			*pImage				= NULL;
	OVERLAY::ObjectCurve			*pCurve				= NULL;
	OVERLAY::ObjectLinkedLine		*pLinkedLine		= NULL;
	OVERLAY::ObjectLinkedMultiLine	*pLinkedMultiLine	= NULL;
	OVERLAY::ObjectLinkedCurve		*pLinkedCurve		= NULL;
	OVERLAY::ObjectLinkedMultiCurve	*pLinkedMultiCurve	= NULL;

	switch(eObjectType)
	{
	case OVERLAY::ELLIPSE:
		pEllipse		= new OVERLAY::ObjectEllipse();
		pObject	= (OVERLAY::OBJECT*)pEllipse;

		break;
	case OVERLAY::RECT_TYPE:
		pRect			= new OVERLAY::ObjectRect();
		pObject	= (OVERLAY::OBJECT*)pRect;

		break;
	case OVERLAY::ROUND_RECT:
		pRoundRect		= new OVERLAY::ObjectRoundRect();
		pObject	= (OVERLAY::OBJECT*)pRoundRect;

		break;
	case OVERLAY::TRIANGLE:
		pTriangle		= new OVERLAY::ObjectTriangle();
		pObject	= (OVERLAY::OBJECT*)pTriangle;

		break;
	case OVERLAY::PENTAGON:
		pPentagon		= new OVERLAY::ObjectPentagon();
		pObject	= (OVERLAY::OBJECT*)pPentagon;

		break;
	case OVERLAY::SIX_ANGLE:
		pSixAngle		= new OVERLAY::ObjectSixAngle();
		pObject	= (OVERLAY::OBJECT*)pSixAngle;

		break;
	case OVERLAY::EIGHT_ANGLE:
		pEightAngle		= new OVERLAY::ObjectEightAngle();
		pObject	= (OVERLAY::OBJECT*)pEightAngle;

		break;
	case OVERLAY::CURVE:
		pCurve			= new OVERLAY::ObjectCurve();
		pObject	= (OVERLAY::OBJECT*)pCurve;

		break;
	case OVERLAY::DIAMOND:
		pDiamond		= new OVERLAY::ObjectDiamond();
		pObject	= (OVERLAY::OBJECT*)pDiamond;

		break;
	case OVERLAY::LINE:
		pLine			= new OVERLAY::ObjectLine();
		pObject	= (OVERLAY::OBJECT*)pLine;

		break;
	case OVERLAY::POLYGON:
		pPolygon		= new OVERLAY::ObjectPolygon();
		pObject	= (OVERLAY::OBJECT*)pPolygon;

		break;
	case OVERLAY::POLYLINE:
		pPolyLine		= new OVERLAY::ObjectPolyLine();
		pObject	= (OVERLAY::OBJECT*)pPolyLine;

		break;
	case OVERLAY::ARC:
		pArc			= new OVERLAY::ObjectArc();
		pObject	= (OVERLAY::OBJECT*)pArc;
		
		break;
	case OVERLAY::TEXT:
		pText			= new OVERLAY::ObjectText();
		pObject	= (OVERLAY::OBJECT*)pText;
	
		break;
	case OVERLAY::PIE:
		pPie			= new OVERLAY::ObjectPie();
		pObject	= (OVERLAY::OBJECT*)pPie;

		break;
	case OVERLAY::IMAGE:
		pImage			= new OVERLAY::ObjectImage(strImageFileName, nStrImageFileNameLen);
		pObject	= (OVERLAY::OBJECT*)pImage;

		break;
	case OVERLAY::LINKED_LINE:
		pLinkedLine		= new OVERLAY::ObjectLinkedLine(2);
		pObject		= (OVERLAY::OBJECT*)pLinkedLine;

		break;
	case OVERLAY::LINKED_MULTI_LINE:
		pLinkedMultiLine	= new OVERLAY::ObjectLinkedMultiLine(3);
		pObject		= (OVERLAY::OBJECT*)pLinkedMultiLine;

		break;
	case OVERLAY::LINKED_CURVE:
		pLinkedCurve		= new OVERLAY::ObjectLinkedCurve(2);
		pObject		= (OVERLAY::OBJECT*)pLinkedCurve;

		break;
	case OVERLAY::LINKED_MULTI_CURVE:
		pLinkedMultiCurve	= new OVERLAY::ObjectLinkedMultiCurve(3);
		pObject		= (OVERLAY::OBJECT*)pLinkedMultiCurve;

		break;	
	default:
		break;
	}

	return pObject;
}
//}

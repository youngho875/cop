#include "pch.h"

#include "OverlayFileHeader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
	OverlayFileHeader::OverlayFileHeader()
	{
		nFileSize = 0;
		nFileCode = OVERLAY_FILE_MAGIC_NUM;
		memset(m_szLayerName, 0, sizeof(m_szLayerName));
	}

	OverlayFileHeader::~OverlayFileHeader()
	{
	}

	BOOL OverlayFileHeader::SetFileName(char* strFileName, int nStrLen)
	{
		if (nStrLen >= MAX_LAYER_NAME)
			return FALSE;

		memcpy(m_szLayerName, strFileName, nStrLen);
		return TRUE;
	}
//}
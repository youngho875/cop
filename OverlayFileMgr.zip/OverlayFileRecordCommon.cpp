#include "pch.h"
#include "OverlayFileRecordCommon.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
	OverlayFileRecordCommon::OverlayFileRecordCommon()
	{
		m_eType = OVERLAY::NULL_TYPE;
		m_nPoints = 0;
		m_nPointIndex = 0;
		memset(m_pt_out_line, 0, sizeof(m_pt_out_line));
		memset(m_pt, 0, sizeof(m_pt));
		memset(m_dSweepAngle, 0, sizeof(m_dSweepAngle));
		m_nObjectID = 0;
		nGroupID = 0;

		m_nLinkedLine_Start_ObjectID = 0;
		m_nLinkedLine_End_ObjectID = 0;

		m_nLinkedLine_start_ObjectPointID = 0;
		m_nLinkedLine_end_ObjectPointID = 0;
	}

	OverlayFileRecordCommon::~OverlayFileRecordCommon()
	{
	}
//}
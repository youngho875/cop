#include "pch.h"
#include "OverlayFileRecordImage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
	OverlayFileRecordImage::OverlayFileRecordImage()
	{
		m_nImageSize = 0;
		memset(m_szImageFileName, 0, sizeof(m_szImageFileName));
	}

	OverlayFileRecordImage::~OverlayFileRecordImage()
	{
	}
//}
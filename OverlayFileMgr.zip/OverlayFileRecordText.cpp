#include "pch.h"
#include "OverlayFileRecordText.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//namespace OVERLAY
//{
	OverlayFileRecordText::OverlayFileRecordText()
	{
		m_dFontSize = 10;
		m_FontColor = 0xff000000;
		m_eFamilyName = OVERLAY::FAMILY_NAME_GOOLIM;
		m_eFontStyle = Gdiplus::FontStyleRegular;
		m_eUnit = Gdiplus::UnitPoint;
		memset(m_Text, 0, sizeof(m_Text));
	}

	OverlayFileRecordText::~OverlayFileRecordText()
	{
	}
//}
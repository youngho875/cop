#include "pch.h"
#include "ObjectLinkedCurveDraw.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	CObjectLinkedCurveDraw::CObjectLinkedCurveDraw()
	{
	}

	CObjectLinkedCurveDraw::~CObjectLinkedCurveDraw()
	{
	}
}

#include "pch.h"
#include "ObjectEightAngle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	ObjectEightAngle::ObjectEightAngle()
		:OBJECT(EIGHT_ANGLE, POINTS_OF_OBJECT_EIGHTANGLE)
	{
	}

	ObjectEightAngle::~ObjectEightAngle()
	{
	}
}
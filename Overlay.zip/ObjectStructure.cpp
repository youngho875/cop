#include "pch.h"
#include "ObjectStructure.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

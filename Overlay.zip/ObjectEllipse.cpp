#include "pch.h"
#include "ObjectEllipse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	ObjectEllipse::ObjectEllipse()
		:OBJECT(ELLIPSE, POINTS_OF_OBJECT_ELLIPSE)
	{
	}

	ObjectEllipse::~ObjectEllipse()
	{
	}
}
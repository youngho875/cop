#include "pch.h"
#include "ObjectSixAngle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	ObjectSixAngle::ObjectSixAngle()
		:OBJECT(SIX_ANGLE, POINTS_OF_OBJECT_SIXANGLE)
	{
	}

	ObjectSixAngle::~ObjectSixAngle()
	{
	}
}
#include "pch.h"
#include "ObjectLinkedMultiCurveDraw.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	CObjectLinkedMultiCurveDraw::CObjectLinkedMultiCurveDraw()
	{
	}

	CObjectLinkedMultiCurveDraw::~CObjectLinkedMultiCurveDraw()
	{
	}
}

#include "pch.h"
#include "ObjectDiamond.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace OVERLAY
{
	ObjectDiamond::ObjectDiamond()
		:OBJECT(DIAMOND, POINTS_OF_OBJECT_DIAMOND)
	{
	}

	ObjectDiamond::~ObjectDiamond()
	{
	}
}